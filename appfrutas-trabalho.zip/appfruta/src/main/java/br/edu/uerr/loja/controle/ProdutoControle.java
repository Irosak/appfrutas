package br.edu.uerr.loja.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import br.edu.uerr.loja.modelo.Produto;
import br.edu.uerr.loja.repositorio.EmpresaRepositorio;
import br.edu.uerr.loja.repositorio.ProdutoRepositorio;

@Controller
public class ProdutoControle {

	@Autowired
	ProdutoRepositorio produtoRepositorio;
	
	@Autowired
	EmpresaRepositorio empresaRepositorio;
	
	//Listar
	
	@GetMapping("/produto")
	public String abreProduto(Model modelo) {
		modelo.addAttribute("listaProduto", produtoRepositorio.findAll());
		return "produto";
	}
	
	//From
	
	@GetMapping("/cadastroProduto")
	public String novoProduto(Model model) {
		Produto produto = new Produto();
		
		model.addAttribute("listaEmpresas", empresaRepositorio.findAll());		
		
		model.addAttribute("produto",produto);
		return "formProduto";
	}
	
	//Salvar/Alterar
	
	@GetMapping("/deletarProduto/{idProduto}")
	public String delEmpresa(@PathVariable("idProduto") Integer idProduto, Model modelo) throws IllegalArgumentException {
		
		Produto produto = produtoRepositorio.findById(idProduto)
				.orElseThrow(()->new IllegalArgumentException("Este produto não existe: "+idProduto));
		produtoRepositorio.delete(produto);
				
		modelo.addAttribute("listaProdutos", produtoRepositorio.findAll());
		return "produto";
	}
	@GetMapping("/editarProduto/{idProduto}")
	public String editEmpresa(@PathVariable("idProduto") Integer idProduto, Model modelo, Object produto) {
		
		Produto produto1 = produtoRepositorio.findById(idProduto)
				.orElseThrow(()->new IllegalArgumentException("Esta empresa não existe: "+idProduto));
				
		modelo.addAttribute("produto", produto1);
		return "formproduto";
	}
	
	
	//Deletar
	
}